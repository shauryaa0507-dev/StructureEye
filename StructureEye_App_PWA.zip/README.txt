StructureEye Mobile Web App (PWA)

This package uses the custom generated StructureEye architectural-eye artwork as its welcome logo and app icons.

Install: host these files on HTTPS (or localhost), open index.html in a supported browser, then choose Install app / Add to Home Screen. A PWA cannot be installed reliably by opening the HTML directly from a ZIP or file:// URL.

The app remains browser-based; this package is not a compiled APK. Offline caching is provided by the included service worker after the first visit on a supported origin.
