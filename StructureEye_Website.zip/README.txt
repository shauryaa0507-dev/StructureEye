StructureEye Website Package

Open index.html for a local preview. The site uses the custom generated StructureEye artwork as the homepage logo and favicon. For public hosting, upload index.html and structureeye-logo.png together.
